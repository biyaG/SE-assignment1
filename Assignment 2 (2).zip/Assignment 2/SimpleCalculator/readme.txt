It's a simple calculator that adds and subtracts two numbers, by taking the numbers from users.

since the java swing API is based on an Event driven design pattern the application is used to demonstrate
this pattern.


