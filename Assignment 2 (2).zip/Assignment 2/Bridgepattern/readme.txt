It's a drawing app that a circle can be drawn in different colors using the same abstract 
class method but different implementer classes.

The application uses the bridge design pattern -
bridge is used when we need to decouple an abstraction from its implementation so that 
the two can vary independently. the classes can be altered structurally without affecting 
each other. 

There is a DrawApp interface which is acting as a bridge implementer and concrete classes 
Red,blue implementing the DrawApp interface.Shape is an abstract class and will 
use object of DrawApp. and the main method which is Bridgepatten will use shape class to draw 
different colored circle.